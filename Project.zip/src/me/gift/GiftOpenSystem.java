package me.gift;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class GiftOpenSystem implements Listener {
	@SuppressWarnings("deprecation")
	@EventHandler
	public void gift(PlayerInteractEvent e) {
		if (e.getAction() == Action.LEFT_CLICK_BLOCK) {
			Player p = e.getPlayer();
			FileConfiguration config = Main.getInst().getConfig();
			List<String> gifts = new ArrayList<String> ();
			gifts = config.getStringList(p.getName()+".gifts");
			if (gifts != null) {
				for (int i = 0; i < gifts.size(); i ++) {
					if (p.getInventory().getItemInHand() != null && p.getInventory().getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase(gifts.get(i)) && p.getInventory().getItemInHand().getType() == Material.CHEST) {
						p.getInventory().setItemInHand(new ItemStack(Material.AIR));
						p.sendMessage("�8>> �aHappy Holidays!");
						p.getInventory().addItem(new ItemStack(Material.DIAMOND, 1));
						gifts.remove(gifts.indexOf(gifts.get(i)));
						config.set(p.getDisplayName()+".gifts", gifts);
						Main.getInst().saveConfig();
					}
				}
			} else {}
		}
	}
}
