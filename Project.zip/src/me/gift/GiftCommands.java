package me.gift;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class GiftCommands implements CommandExecutor {

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("gift")) {
			if (args.length == 2) {
				if (Bukkit.getPlayer(args[0]) != null) {
						List<String> gifts = new ArrayList<String> ();
						Player canopen = Bukkit.getPlayer(args[0]);
						FileConfiguration config = Main.getInst().getConfig();
						int mistakes = 0;
						gifts = config.getStringList(canopen.getName()+".gifts");
						for (int i = 0; i < gifts.size(); i ++) {
							if (!gifts.get(i).equalsIgnoreCase(args[1])){
								
							} else {
								mistakes ++;
							}
						}
						if (mistakes > 0) {
							sender.sendMessage("�8>>�c This player owns already a gift with this same Identificator.");
						} else {
							gifts.add(args[1]);
							config.set(canopen.getName()+".gifts", gifts);
							Main.getInst().saveConfig();
							sender.sendMessage("�8>>�a Gift added to the list!");
							canopen.sendMessage("�8>> �a�n"+sender.getName()+"�a gave you a gift under code�a�n "+args[1].toUpperCase()+"�a!");
						}
				} else {
					sender.sendMessage("�8>>�c This player isn't online.");
				}
			} else {
				sender.sendMessage("�8>> �c/gift <Who can Open> <Required chest name / To Receive>");
			}
		}
	return false;
	}

}
