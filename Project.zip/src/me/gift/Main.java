package me.gift;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
	public static Main inst;
	public void onEnable() {
		inst = this;
		getCommand("gift").setExecutor(new GiftCommands());
		getServer().getPluginManager().registerEvents(new GiftOpenSystem(), this);
	}
	public static Main getInst() {
		return inst;
	}
}
